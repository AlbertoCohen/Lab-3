#include <sys/ipc.h>
#include "def.h"
#include "stdio.h"
#include "stdlib.h"

key_t creo_clave(){
	key_t clave;
	clave = ftok ("/bin/ls", CLAVE_BASE);
	if (clave == (key_t)-1){
		printf("No puedo conseguir clave para semaforo\n");
		exit(0);
	}
	return clave;
}
