#ifndef FUNCIONES
#define FUNCIONES

int devolverNumero(int inDesde, int inHasta);

#endif
