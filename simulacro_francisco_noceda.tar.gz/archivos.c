#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "def.h"
#include "archivos.h"


FILE *fp;

int inAbrirArchivo(char *nombreArchivo, char *modo){
    fp = fopen(nombreArchivo, modo); /*devuelve puntero*/
    if(fp == NULL){
        printf("Error apertura de archivo\n");
        return FALSE;
    } else {
        return TRUE;
    }
}

void inCerrarArchivo(){ /*cerrar archivo*/
    fclose(fp);
}

int inRenombrarArchivo(char *nombreViejoArchivo, char *nombreNuevoArchivo) { /*renombra el un archivo con el nombre viejo y el nombre nuevo */
    return rename(nombreViejoArchivo, nombreNuevoArchivo);
}

int inEscribirArchivo(char *szTexto){ /*escribe el archivo con un parametro*/
    return fprintf(fp, "%s", szTexto);
}

void inLeerArchivoCompleto(){ 
    char linea[100];
    while (fgets(linea, sizeof(linea), fp)) {
        printf("%s", linea);
    }
}
