#ifndef DEFINICIONES
#define DEFINICIONES

#define TRUE 1
#define FALSE 0
#define CLAVE_BASE 33

#define MAX_CHAR 100

#define VERDE 1
#define ROJO 0

typedef struct{
    int nro_avion;
    char ciudad[MAX_CHAR];
} Avion;

#endif

