#ifndef _GLOBAL
#define _GLOBAL



#endif
