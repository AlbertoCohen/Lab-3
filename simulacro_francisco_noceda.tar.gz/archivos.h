#ifndef _ARCHIVOS
#define _ARCHIVOS

int inAbrirArchivo(char *nombreArchivo, char *modo);
void inCerrarArchivo();
int inRenombrarArchivo(char *nombreViejoArchivo, char *nombreNuevoArchivo);
int inEscribirArchivo(char *szTexto);
void inLeerArchivoCompleto();

#endif
