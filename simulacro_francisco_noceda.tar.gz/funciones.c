#include "stdlib.h"
#include "stdio.h"
#include "string.h"
#include "funciones.h"

int devolverNumero(int inDesde, int inHasta){
	return rand() % (inHasta-inDesde+1) + inDesde;
}
